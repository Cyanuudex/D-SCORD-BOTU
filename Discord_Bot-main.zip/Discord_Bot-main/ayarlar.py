#settings.py in original

ayarlar = {
    "on_taki": ">", #ön takı, prefix (maybe it won't work if we call it different here)
    "TOKEN": "TOKEN BURADA DEPOLANACAK"
}
